// Initialize SpeechRecognition object
const recognition = new webkitSpeechRecognition();
recognition.continuous = false;
recognition.lang = 'en-US';
recognition.interimResults = false;

// Initialize SpeechSynthesis object
const synthesis = window.speechSynthesis;

// Flag to indicate if recognition is active
let isListening = false;

// Get reference to the start listening button
const startListeningButton = document.getElementById("start-listening-button");

function sendMessage() {
    var userInput = document.getElementById("user-input").value;
    if (userInput.trim() !== "") {
        appendMessage("You: " + userInput, "right-message");
        document.getElementById("user-input").value = "";
        fetch("/send-message", {
            method: "POST",
            body: JSON.stringify({ message: userInput }),
            headers: {
                "Content-Type": "application/json"
            }
        })
        .then(response => response.json())
        .then(data => {
            if (data.response) {
                appendMessage("Bot: " + data.response, "left-message");
                speak(data.response); // Speak the response
            } else {
                appendMessage("Bot: I'm sorry, I didn't understand that.", "left-message");
                speak("I'm sorry, I didn't understand that."); // Speak a generic response
            }
        })
        .catch(error => {
            console.error('Error sending message:', error);
            appendMessage("Bot: Oops! Something went wrong.", "left-message"); // Display error message
        });
    }
}

function speak(text) {
    var utterance = new SpeechSynthesisUtterance();
    utterance.text = text;
    synthesis.speak(utterance);
}

// Start voice recognition
// Function to create and display a notification
function showNotification() {
    const chatContainer = document.querySelector(".chat-container");
    const notification = document.createElement("div");
    notification.textContent = "Microphone is on";
    notification.classList.add("notification");
    chatContainer.appendChild(notification);

    // Trigger reflow to restart transition
    notification.offsetHeight; // eslint-disable-line no-unused-expressions

    notification.classList.add("show"); // Show the notification

    setTimeout(() => {
        notification.classList.remove("show"); // Hide the notification
        setTimeout(() => {
            chatContainer.removeChild(notification); // Remove the notification from the DOM
        }, 500); // Wait for the transition to complete before removing
    }, 3000); // Hide the notification after 3 seconds
}

function startListening() {
    recognition.start();
    isListening = true;
    showNotification()
}

// When speech recognition detects speech, send the recognized text to the server
recognition.onresult = function(event) {
    var transcript = event.results[0][0].transcript;
    appendMessage("You: " + transcript, "right-message");
    fetch("/send-message", {
        method: "POST",
        body: JSON.stringify({ message: transcript }),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.response) {
            appendMessage("Bot: " + data.response, "left-message");
            speak(data.response); // Speak the response
        } else {
            appendMessage("Bot: I'm sorry, I didn't understand that.", "left-message");
            speak("I'm sorry, I didn't understand that."); // Speak a generic response
        }
    })
    .catch(error => {
        console.error('Error sending message:', error);
        appendMessage("Bot: Oops! Something went wrong.", "left-message"); // Display error message
    });
}

// If there's an error with speech recognition, stop listening
recognition.onerror = function(event) {
    console.error('Speech recognition error:', event.error);
    isListening = false;
}

function appendMessage(message, side) {
    var chatBox = document.getElementById("chat-box");
    var newMessage = document.createElement("div");
    newMessage.textContent = message;
    newMessage.classList.add("message", side);
    chatBox.appendChild(newMessage);
    chatBox.scrollTop = chatBox.scrollHeight;
}
